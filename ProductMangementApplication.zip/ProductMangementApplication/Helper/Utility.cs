﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace ProductMangementApplication.Helper
{
    public static class Utility
    {


        public static string constring = "Data Source=DESKTOP-F5AKH99/SQLEXPRESS;Initial Catalog=Product_Catelogue;Integrated Security=True";

        private static string cName = "Data Source=.; Initial Catalog=Product_Catelogue;User ID=DESKTOP-F5AKH99/Pranoti;Password=2991";
        public static string CName
        {
            get => cName;
        }
    }
}