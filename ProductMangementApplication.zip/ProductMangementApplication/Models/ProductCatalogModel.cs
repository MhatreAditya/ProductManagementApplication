﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductManagemntApplication.Models
{
    public class ProductCatalogModel
    {
        public List<ProductModel> Products { get; set;}

        public ProductModel Product { get; set; }

        public List<CategoryModel> Categories { get; set; }
    }
}