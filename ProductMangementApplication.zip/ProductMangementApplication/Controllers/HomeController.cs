﻿using ProductManagemntApplication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ProductManagemntApplication.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var model = new Models.ProductCatalogModel();
            var products = GetProducts();

            model.Products = products;

            return View(model);
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(ProductModel product)
        {
            return View();
        }

        [HttpGet]
        public ActionResult Edit(string id)
        {
            var products = GetProducts();

            var product = products.Where(p => p.ProductId == id).FirstOrDefault();

            var model = new ProductCatalogModel();
            model.Product = product;

            return View(model);
        }

        [HttpPost]
        public ActionResult Edit(ProductModel product, string productId)
        {
            return View();
        }

        [HttpGet]
        public ActionResult Details(string id)
        {
            var products = GetProducts();

            var product = products.Where(p => p.ProductId == id).FirstOrDefault();

            var model = new ProductCatalogModel();
            model.Product = product;
            return View(model);
        }

        [HttpPost]
        public ActionResult Delete(string productId)
        {
            return View();
        }

        public List<ProductModel> GetProducts()
        {
            var products = new List<Models.ProductModel>();

            products.Add(new Models.ProductModel
            {
                ProductId = "1",
                ProductName = "Oreo",
                CategoryId = "1",
                CategoryName = "Biscuits"
            });

            products.Add(new Models.ProductModel
            {
                ProductId = "2",
                ProductName = "Britania",
                CategoryId = "1",
                CategoryName = "Biscuits"
            });

            products.Add(new Models.ProductModel
            {
                ProductId = "3",
                ProductName = "Kit-Kat",
                CategoryId = "2",
                CategoryName = "Chocolates"
            });

            products.Add(new Models.ProductModel
            {
                ProductId = "6",
                ProductName = "5 Star",
                CategoryId = "2",
                CategoryName = "Chocolates"
            });

            products.Add(new Models.ProductModel
            {
                ProductId = "4",
                ProductName = "Coca Cola",
                CategoryId = "3",
                CategoryName = "Beverages"
            });

            products.Add(new Models.ProductModel
            {
                ProductId = "5",
                ProductName = "Pepsi",
                CategoryId = "3",
                CategoryName = "Beverages"
            });

            return products;
        }
    }
}